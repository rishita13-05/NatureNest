﻿using System;
using System.Collections.Generic;

namespace NatureNest.Models.dbcontext;

public partial class Logtable
{
    public string? Name { get; set; }

    public string? Logby { get; set; }
}
