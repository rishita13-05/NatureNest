﻿using System;
using System.Collections.Generic;

namespace NatureNest.Models.dbcontext;

public partial class UserRegisteration
{
    public int UserId { get; set; }

    public string? FullName { get; set; }

    public string? UserName { get; set; }

    public string Email { get; set; } = null!;

    public string? Password { get; set; }

    public string? MobileNo { get; set; }

    public string? State { get; set; }

    public string? City { get; set; }

    public byte[]? ProfilePicUrl { get; set; }

    public string? Bio { get; set; }

    public bool? TermConditions { get; set; }

    public bool? IsAdmin { get; set; }

    public DateTime? Createdat { get; set; }

    public bool? IsActive { get; set; }

    public virtual ICollection<Comment> Comments { get; set; } = new List<Comment>();

    public virtual ICollection<Like> Likes { get; set; } = new List<Like>();

    public virtual ICollection<Post> Posts { get; set; } = new List<Post>();

    public virtual ICollection<Report> Reports { get; set; } = new List<Report>();
}
