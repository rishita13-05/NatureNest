﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace NatureNest.Models.dbcontext;

public partial class NaturenestContext : DbContext
{
    public NaturenestContext()
    {
    }

    public NaturenestContext(DbContextOptions<NaturenestContext> options)
        : base(options)
    {
    }

    public virtual DbSet<City> Cities { get; set; }

    public virtual DbSet<Comment> Comments { get; set; }

    public virtual DbSet<Like> Likes { get; set; }

    public virtual DbSet<Logtable> Logtables { get; set; }

    public virtual DbSet<Naturenestsub> Naturenestsubs { get; set; }

    public virtual DbSet<Post> Posts { get; set; }

    public virtual DbSet<Report> Reports { get; set; }

    public virtual DbSet<State> States { get; set; }

    public virtual DbSet<Testing> Testings { get; set; }

    public virtual DbSet<UserRegisteration> UserRegisterations { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=localhost;Database=Naturenest;User ID=sa;Password=India123*;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<City>(entity =>
        {
            entity.HasKey(e => e.CityId).HasName("PK__Cities__B4BEB95E017A72E1");

            entity.Property(e => e.CityId).HasColumnName("cityId");
            entity.Property(e => e.City1)
                .HasMaxLength(100)
                .HasColumnName("City");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("createdAt");
            entity.Property(e => e.StateId).HasColumnName("stateId");

            entity.HasOne(d => d.State).WithMany(p => p.Cities)
                .HasForeignKey(d => d.StateId)
                .HasConstraintName("FK__Cities__stateId__44CA3770");
        });

        modelBuilder.Entity<Comment>(entity =>
        {
            entity.HasKey(e => e.CommentId).HasName("PK__Comments__C3B4DFAAD4B1E406");

            entity.Property(e => e.CommentId)
                .HasMaxLength(100)
                .HasColumnName("CommentID");
            entity.Property(e => e.CommentText).HasMaxLength(500);
            entity.Property(e => e.CommentedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.PostId).HasColumnName("PostID");

            entity.HasOne(d => d.EmailNavigation).WithMany(p => p.Comments)
                .HasForeignKey(d => d.Email)
                .HasConstraintName("FK__Comments__Email__01142BA1");

            entity.HasOne(d => d.Post).WithMany(p => p.Comments)
                .HasForeignKey(d => d.PostId)
                .HasConstraintName("FK__Comments__PostID__00200768");
        });

        modelBuilder.Entity<Like>(entity =>
        {
            entity.HasKey(e => e.LikeId).HasName("PK__Likes__4FC592FB57BB46A9");

            entity.Property(e => e.LikeId).HasColumnName("likeID");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.PostId).HasColumnName("PostID");

            entity.HasOne(d => d.EmailNavigation).WithMany(p => p.Likes)
                .HasForeignKey(d => d.Email)
                .HasConstraintName("FK__Likes__Email__7C4F7684");

            entity.HasOne(d => d.Post).WithMany(p => p.Likes)
                .HasForeignKey(d => d.PostId)
                .HasConstraintName("FK__Likes__PostID__7B5B524B");
        });

        modelBuilder.Entity<Logtable>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("logtable");

            entity.Property(e => e.Logby)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("logby");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Naturenestsub>(entity =>
        {
            entity.HasKey(e => e.EmailId);

            entity.ToTable("naturenestsub", tb => tb.HasTrigger("logintrigger"));

            entity.Property(e => e.EmailId)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("emailID");
            entity.Property(e => e.City)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("city");
            entity.Property(e => e.Fullname)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("fullname");
            entity.Property(e => e.Mobileno).HasColumnName("mobileno");
            entity.Property(e => e.State)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("state");
            entity.Property(e => e.Username)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("username");
        });

        modelBuilder.Entity<Post>(entity =>
        {
            entity.HasKey(e => e.PostId).HasName("PK__Posts__AA126038B7AC9123");

            entity.Property(e => e.PostId).HasColumnName("PostID");
            entity.Property(e => e.Caption).HasMaxLength(500);
            entity.Property(e => e.Category).HasMaxLength(50);
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.IsApproved).HasDefaultValue(true);
            entity.Property(e => e.IsDeleted).HasDefaultValue(false);
            entity.Property(e => e.Tags).HasMaxLength(100);

            entity.HasOne(d => d.EmailNavigation).WithMany(p => p.Posts)
                .HasForeignKey(d => d.Email)
                .HasConstraintName("FK__Posts__Email__75A278F5");
        });

        modelBuilder.Entity<Report>(entity =>
        {
            entity.HasKey(e => e.ReportId).HasName("PK__Reports__D5BD48E500FC4D85");

            entity.Property(e => e.ReportId)
                .ValueGeneratedNever()
                .HasColumnName("ReportID");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.IsResolved).HasDefaultValue(false);
            entity.Property(e => e.PostId).HasColumnName("PostID");
            entity.Property(e => e.ReportedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ReportedReason).HasMaxLength(200);

            entity.HasOne(d => d.EmailNavigation).WithMany(p => p.Reports)
                .HasForeignKey(d => d.Email)
                .HasConstraintName("FK__Reports__Email__05D8E0BE");

            entity.HasOne(d => d.Post).WithMany(p => p.Reports)
                .HasForeignKey(d => d.PostId)
                .HasConstraintName("FK__Reports__PostID__04E4BC85");
        });

        modelBuilder.Entity<State>(entity =>
        {
            entity.HasKey(e => e.StateId).HasName("PK__States__A667B9E1D1207696");

            entity.Property(e => e.StateId).HasColumnName("stateId");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("createdAt");
            entity.Property(e => e.StateName)
                .HasMaxLength(50)
                .HasColumnName("stateName");
        });

        modelBuilder.Entity<Testing>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("testing");

            entity.Property(e => e.City)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("city");
            entity.Property(e => e.EmailId)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("emailID");
            entity.Property(e => e.Fullname)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("fullname");
            entity.Property(e => e.Mobileno).HasColumnName("mobileno");
            entity.Property(e => e.State)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("state");
            entity.Property(e => e.Username)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("username");
        });

        modelBuilder.Entity<UserRegisteration>(entity =>
        {
            entity.HasKey(e => e.Email).HasName("PK__UserRegi__A9D10535457AFFD5");

            entity.ToTable("UserRegisteration");

            entity.HasIndex(e => e.UserName, "UQ__UserRegi__C9F284565CCBEA6F").IsUnique();

            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.Bio).HasMaxLength(255);
            entity.Property(e => e.City)
                .HasMaxLength(50)
                .HasColumnName("city");
            entity.Property(e => e.Createdat)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("createdat");
            entity.Property(e => e.FullName).HasMaxLength(50);
            entity.Property(e => e.IsActive).HasDefaultValue(true);
            entity.Property(e => e.IsAdmin).HasDefaultValue(false);
            entity.Property(e => e.MobileNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Password).HasMaxLength(20);
            entity.Property(e => e.ProfilePicUrl).HasColumnName("ProfilePicURL");
            entity.Property(e => e.State)
                .HasMaxLength(50)
                .HasColumnName("state");
            entity.Property(e => e.UserId)
                .ValueGeneratedOnAdd()
                .HasColumnName("UserID");
            entity.Property(e => e.UserName).HasMaxLength(100);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
