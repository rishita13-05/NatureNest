﻿using System;
using System.Collections.Generic;

namespace NatureNest.Models.dbcontext;

public partial class Sc
{
    public string? State { get; set; }
    public string? City { get; set; }
    public DateTime? Createdat { get; set; }
}
