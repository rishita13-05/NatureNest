﻿using System;
using System.Collections.Generic;

namespace NatureNest.Models.dbcontext;

public partial class Testing
{
    public string? Username { get; set; }

    public string? Fullname { get; set; }

    public int? Mobileno { get; set; }

    public string EmailId { get; set; } = null!;

    public int? Password { get; set; }

    public string? State { get; set; }

    public string? City { get; set; }
}
