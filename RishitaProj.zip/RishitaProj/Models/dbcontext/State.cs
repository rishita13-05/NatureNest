﻿using System;
using System.Collections.Generic;

namespace NatureNest.Models.dbcontext;

public partial class State
{
    public int StateId { get; set; }

    public string? StateName { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual ICollection<City> Cities { get; set; } = new List<City>();
}
