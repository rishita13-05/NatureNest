﻿using System;
using System.Collections.Generic;

namespace NatureNest.Models.dbcontext;

public partial class Report
{
    public int ReportId { get; set; }

    public int? PostId { get; set; }

    public string? Email { get; set; }

    public string? ReportedReason { get; set; }

    public bool? IsResolved { get; set; }

    public DateTime? ReportedAt { get; set; }

    public virtual UserRegisteration? EmailNavigation { get; set; }

    public virtual Post? Post { get; set; }
}
