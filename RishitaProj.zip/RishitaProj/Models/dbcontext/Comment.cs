﻿using System;
using System.Collections.Generic;

namespace NatureNest.Models.dbcontext;

public partial class Comment
{
    public string CommentId { get; set; } = null!;

    public int? PostId { get; set; }

    public string? Email { get; set; }

    public string? CommentText { get; set; }

    public DateTime? CommentedAt { get; set; }

    public virtual UserRegisteration? EmailNavigation { get; set; }

    public virtual Post? Post { get; set; }
}
