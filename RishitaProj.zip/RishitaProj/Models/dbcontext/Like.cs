﻿using System;
using System.Collections.Generic;

namespace NatureNest.Models.dbcontext;

public partial class Like
{
    public int LikeId { get; set; }

    public int? PostId { get; set; }

    public string? Email { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual UserRegisteration? EmailNavigation { get; set; }

    public virtual Post? Post { get; set; }
}
