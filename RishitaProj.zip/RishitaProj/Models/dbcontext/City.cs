﻿using System;
using System.Collections.Generic;

namespace NatureNest.Models.dbcontext;

public partial class City
{
    public int CityId { get; set; }

    public string City1 { get; set; } = null!;

    public int? StateId { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual State? State { get; set; }
}
