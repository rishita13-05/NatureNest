﻿using System;
using System.Collections.Generic;

namespace NatureNest.Models.dbcontext;

public partial class Post
{
    public int PostId { get; set; }

    public string? Email { get; set; }

    public string? Caption { get; set; }

    public byte[]? ImageUrl { get; set; }

    public string? Category { get; set; }

    public string? Tags { get; set; }

    public bool? IsApproved { get; set; }

    public bool? IsDeleted { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual ICollection<Comment> Comments { get; set; } = new List<Comment>();

    public virtual UserRegisteration? EmailNavigation { get; set; }

    public virtual ICollection<Like> Likes { get; set; } = new List<Like>();

    public virtual ICollection<Report> Reports { get; set; } = new List<Report>();
}
