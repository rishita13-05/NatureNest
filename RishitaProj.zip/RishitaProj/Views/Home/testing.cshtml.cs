using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace NatureNest.Views.Home
{
    public class testingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
