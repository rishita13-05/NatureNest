﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NatureNest.Models.dbcontext;

namespace NatureNest.Controllers
{

    [Authorize(Roles ="Admin")] // Now this whole admin controller need to auth
    // now only admin role have access to this controller
    public class AdminController : Controller
    {
       
            private readonly ILogger<AdminController> _logger;
            private readonly NaturenestContext _dbcon;
            //injectection done of dbcon
            public AdminController(ILogger<AdminController> logger, NaturenestContext dbcon)
            {
                _logger = logger;
                _dbcon = dbcon;
            }
            public IActionResult Index()
            {
                return View();
            }

        [Authorize(Roles = "Admin")]
        public IActionResult UserList()
            {
                return View();
            }
        
        public IActionResult GetAllusers()
        {
           var userData=_dbcon.UserRegisterations.ToList();//getting the data

            return Json(new {data= userData });
            
        }

     
    }
}
