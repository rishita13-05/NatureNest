using System.Diagnostics;
using System.IdentityModel;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Binders;
using Microsoft.EntityFrameworkCore;
using Mono.TextTemplating;
using NatureNest.Models;
using NatureNest.Models.dbcontext;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static Azure.Core.HttpHeader;

namespace NatureNest.Controllers
{
     // [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly NaturenestContext _dbcon;


        //injectection done of dbcon
        public HomeController(ILogger<HomeController> logger, NaturenestContext dbcon)
        {
            _logger = logger;
            _dbcon = dbcon;
        }


        //  [AllowAnonymous] // we write allowanonymous so that user can access some page without login 
        // for now i ma removing this so that it cannot be access later on
         [Authorize]
        public IActionResult Index()
        {
            string email = User.FindFirst(ClaimTypes.Email)?.Value;
            Console.WriteLine(email);
            return View();
        }
       

         [Authorize]    
        public IActionResult userProfileDetials() // use this method to get and set th profile details 
        {
            string email = User.FindFirst(ClaimTypes.Email)?.Value;
            if (email != null) {
                var data = _dbcon.UserRegisterations.Where(u => u.Email == email).FirstOrDefault();
                return Json(new { succes = true, userdata = data });
            }
            return Json(new { succes = false,message="user not found" });
        }
        

        [AllowAnonymous]
        public IActionResult AccessDenied()
        {
            return View();
        }


        private byte[] ConvertImageToByteArray(IFormFile image)
        {
            using (var memoryStream = new MemoryStream())
            {
                image.CopyTo(memoryStream);
                return memoryStream.ToArray();
            }
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Home"); // Change this as per your route
        }
        [AllowAnonymous]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost, AllowAnonymous]
        public async Task<IActionResult> SignIn(string EmailId, string Password)
        {
            bool rememberMe = false;
            try
            {
                var data = _dbcon.UserRegisterations
                                  .FirstOrDefault(u => u.Email == EmailId);

                if (data == null)
                {
                    return Json(new { success = false,isNewuser=true, Message = "you are not registered yet" });
                }

                if (data == null || data.Password != Password)
                {
                    return Json(new { success = false, isNewuser = false, Message = "Email or Password is not correct" });
                }
               

                //if (data.IsAdmin == true)
                //{
                //    return Json(new { success = false, Message = "Your Profile is Blocked or Deleted" });
                //}

                if (data.IsAdmin == null)
                {
                    //var result = await SendEmailNewUser(data.Email, data.Email, data.FullName ?? "Dear");
                    return Json(new { success = false, isNewuser = false, verify = true, email = data.Email });
                }
                // Claims-based identity
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.NameIdentifier, data.FullName ??"userFullName"),
                    new Claim(ClaimTypes.Email, data.Email),
                    new Claim("FullName", data.UserName ?? ""),
                    new Claim("UserID", data.UserId.ToString()),
                    new Claim(ClaimTypes.Role, (bool)data.IsAdmin==true ? "Admin":"User") // here if value of isAdmin==1 then user will have admin role
                };
                var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var authProperties = new AuthenticationProperties
                {
                    AllowRefresh = true,
                    IsPersistent = true, // You can make this dynamic using "Remember Me"
                    ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(10)
                };

                await HttpContext.SignInAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(identity),
                    authProperties);


                return Json(new { success = true, isNewUser = false, data = data, message = "logging Success" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, Message = "Internal error occurred", Error = ex.Message });
            }
        }


        public string GetAllStudentData()
        {
            return "";
        }

        public IActionResult Testing()//created for testing 
        {
            return View();
        }

        public IActionResult GetUserData()
        {
            List<Naturenestsub> mydata = _dbcon.Naturenestsubs.ToList();
            var data = _dbcon.Naturenestsubs.ToList();

            var myrresult = new
            {
                result = data,
                listdata = mydata,
                success = true,
                message = "successfully get the data"
            };

            return Json(myrresult);
        }

        [HttpPost, AllowAnonymous]
        public IActionResult SaveRegisteration(UserRegisteration tbl, [FromForm] IFormFile profilepic)
        {

            try
            {
                var check = _dbcon.UserRegisterations.Where(u => u.Email == tbl.Email).FirstOrDefault();
                if (check == null)
                {
                    UserRegisteration dbsave = new UserRegisteration
                    {
                        FullName = tbl.FullName,//mapping the data
                        UserName = tbl.UserName,//mapping the data
                        MobileNo = tbl.MobileNo,//mapping the data
                        State = tbl.State,//mapping the data
                        City = tbl.City,//mapping the data
                        TermConditions = tbl.TermConditions,//mapping the data
                        Email = tbl.Email,
                        Password = tbl.Password
                    };
                    _dbcon.UserRegisterations.Add(dbsave);//setting the data
                    _dbcon.SaveChanges();
                }
                else
                {
                    check.Bio = tbl.Bio;
                    check.ProfilePicUrl=ConvertImageToByteArray(profilepic);
                    check.UserName = tbl.UserName;
                    _dbcon.UserRegisterations.Update(check);
                    _dbcon.SaveChanges();
                }
                    return Json(new { success = true, message = "Saved successfully" });
            }
            catch (Exception ex)
            {
                    return Json(new { success = false, message = ex });
            }
        }
        [HttpPost]
        public IActionResult SaveProfile(UserRegisteration tb, [FromForm] IFormFile profilepic)
        {
            try
            {
                string userEmail = User.FindFirst(ClaimTypes.Email)?.Value;
                var userdata = _dbcon.UserRegisterations.FirstOrDefault(u => u.Email == userEmail);

                if (userdata != null)
                {
                    // Only update the fields you allow
                    userdata.Bio = tb.Bio;
                    userdata.FullName = tb.FullName;
                    userdata.UserName = tb.UserName;
                    if (profilepic != null && profilepic.Length>0)
                    {
                        userdata.ProfilePicUrl = ConvertImageToByteArray(profilepic);
                    }
                    _dbcon.SaveChanges();  // No need for .Update() � the tracked entity is already being modified
                    return Json(new { success = true, message = "Profile Update successfully" });
                }
                else
                {
                    return Json(new { success = false, message = "not found" });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
           // return Json(new {success=true, message="Profile Update successfully"});
        }


        [HttpGet]
        public IActionResult GetAllPosts(string search)
        {
            string currentUserEmail = User.FindFirst(ClaimTypes.Email)?.Value;
            var query = _dbcon.Posts
                .Where(p => p.IsApproved == true && p.IsDeleted == false);
            // Apply filter only if input is not null or empty
            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(p =>
                    p.Caption.Contains(search) ||
                    p.Tags.Contains(search) ||
                    p.Category.Contains(search) ||
                    p.EmailNavigation.UserName.Contains(search)
                );
            }
            var posts = query
                .Select(p => new
                {
                    p.PostId,
                    p.Caption,
                    p.ImageUrl,
                    p.Tags,
                    p.Category,
                    p.CreatedAt,
                    p.Email,
                    User = new
                    {
                        p.EmailNavigation.UserName,
                        p.EmailNavigation.FullName,
                        p.EmailNavigation.ProfilePicUrl
                    },
                    LikesCount = p.Likes.Count(),
                    CommentsCount = p.Comments.Count(),
                    IsLikedByUser = p.Likes.Any(l => l.Email == currentUserEmail)
                })
                .OrderByDescending(p => p.CreatedAt)
                .ToList();
            return Json(posts);
        }


        [HttpGet]
        public IActionResult GetPostById(int postId)
        {
            var post = _dbcon.Posts
                .Where(p => p.PostId == postId)
                .Select(p => new {
                    p.PostId,
                    p.Caption,
                    p.ImageUrl,
                    p.CreatedAt,
                    User = new
                    {
                        p.EmailNavigation.UserName,
                        p.EmailNavigation.ProfilePicUrl
                    },
                    Comments = p.Comments.Select(c => new {
                        c.CommentId,                      // Include ID for edit/delete
                        c.CommentText,
                        c.CommentedAt,
                        c.Email,                          // Useful to compare with logged-in user
                        UserName = c.EmailNavigation.UserName,
                        ProfilePicUrl = c.EmailNavigation.ProfilePicUrl
                    })
                })
                .FirstOrDefault();

            return Json(post);
        }


        [HttpPost]
        public IActionResult LikeDislikePost([FromBody] Like like)
        {
            string email = User.FindFirst(ClaimTypes.Email)?.Value;
            if (string.IsNullOrEmpty(email))
            {
                return Json(new { success = false, message = "User not authenticated" });
            }
            var existingLike = _dbcon.Likes
                .FirstOrDefault(l => l.PostId == like.PostId && l.Email == email);
            bool liked = false;
            if (existingLike != null)
            {
                // Dislike
                _dbcon.Likes.Remove(existingLike);
            }
            else
            {
                // Like
                _dbcon.Likes.Add(new Like
                {
                    PostId = like.PostId,
                    Email = email,
                    CreatedAt = DateTime.UtcNow
                });
                liked = true;
            }
            _dbcon.SaveChanges();
            // Get updated like count for the post
            int likeCount = _dbcon.Likes.Count(l => l.PostId == like.PostId);
            return Json(new
            {
                success = true,
                liked = liked,
                likesCount = likeCount
            });
        }


        [HttpPost]
        public IActionResult CommentOnPosts([FromBody] Comment cmt, bool editcmt)
        {
            string email = User.FindFirst(ClaimTypes.Email)?.Value;
            if (string.IsNullOrEmpty(email))
                return Json(new { success = false, message = "User not authenticated" });

            if (editcmt && !string.IsNullOrEmpty(cmt.CommentId))
            {
                var existingComment = _dbcon.Comments
                    .FirstOrDefault(x => x.CommentId == cmt.CommentId && x.Email == email);
                if (existingComment != null)
                {
                    existingComment.CommentText = cmt.CommentText;
                    existingComment.CommentedAt = DateTime.Now;
                }
            }
            else
            {
                var newComment = new Comment
                {
                    CommentId = Guid.NewGuid().ToString(),
                    PostId = cmt.PostId,
                    Email = email,
                    CommentText = cmt.CommentText,
                    CommentedAt = DateTime.Now
                };
                _dbcon.Comments.Add(newComment);
            }

            _dbcon.SaveChanges();
            return Json(new { success = true });
        }

        [HttpPost]
        public IActionResult DeleteComment([FromBody] string commentId)
        {
            string email = User.FindFirst(ClaimTypes.Email)?.Value;
            if (string.IsNullOrEmpty(email))
                return Json(new { success = false, message = "User not authenticated" });

            var comment = _dbcon.Comments.FirstOrDefault(c => c.CommentId == commentId && c.Email == email);
            if (comment == null)
                return Json(new { success = false, message = "Comment not found" });

            _dbcon.Comments.Remove(comment);
            _dbcon.SaveChanges();
            return Json(new { success = true });
        }

        public IActionResult RegisterationT(string email)
        {
            var formdata = _dbcon.UserRegisterations.Where(o => o.Email == email);//getting induvidual data of a specific user
            _dbcon.SaveChanges();
            return Json(formdata);
        }
        public IActionResult GetAllUser()
        {
            var formdata = _dbcon.UserRegisterations.ToList();//getting all data
            _dbcon.SaveChanges();
            return Json(formdata);
        }



        [HttpPost]
        public IActionResult Loginmethod(Naturenestsub nb)
        {
            var data = _dbcon.Naturenestsubs.Where(a => a.EmailId == nb.EmailId).FirstOrDefault();

            if (data == null)
            {
                return Json(new { success = false, isNewUser = true, data = "no data", message = "user not found! register yourself" });
            }
            else if (data.EmailId == nb.EmailId && data.Password != nb.Password)
            {
                return Json(new { success = false, isNewUser = false, data = data, message = "Your password is not correct" });
            }
            else if (data.EmailId == nb.EmailId && data.Password == nb.Password)
            {
                return Json(new { success = true, isNewUser = false, data = data, message = "logging Success" });
            }
            else
            {
                return Json(new { success = false, isNewUser = false, data = "no data", message = "Something went wrong" });
            }
        }
        [HttpPost]
        public IActionResult FormTesting(UserRegisteration ft)
        {
            UserRegisteration dbsaved = new UserRegisteration
            {
                UserName = ft.UserName,
                Email = ft.Email,
                Password = ft.Password
            };
            _dbcon.UserRegisterations.Add(dbsaved);
            _dbcon.SaveChanges();
            return Json("Successful");
        }

      //  testing for state city

        [HttpGet]
        public IActionResult GetState()
        {
            var StateData = _dbcon.States.ToList();
            return Json(StateData);
        }

        public IActionResult GetCity(int StateId)
        {
            var CityData = _dbcon.Cities.Where(a => a.StateId ==StateId).ToList();
            return Json(CityData);
        }


        [HttpPost]
        public IActionResult TestingForm(UserRegisteration tt)

        {
            UserRegisteration db = new UserRegisteration
            {
                UserName = tt.UserName,
                Email = tt.Email,
                Password = tt.Password
            };
            _dbcon.UserRegisterations.Add(db);
            _dbcon.SaveChanges();
            return Json("done");
        }
        [HttpPost]
        public IActionResult profile(UserRegisteration ub)
        {
            return Json("successful");
        }


        [Authorize]
        public IActionResult Privacy()
        {
            //var mydata = _dbcon.Naturenestsubs.ToList();
            return View();
        }
        public IActionResult GetData()
        {
            var mydata = _dbcon.Naturenestsubs.ToList();
            return Json(new { success = true, result = mydata, message = "Deepak" });
        }

        [AllowAnonymous]
        public IActionResult Registration()
        {
            return View();
        }


        [HttpPost]
        public IActionResult CreatePost(Post ps, [FromForm] IFormFile ImageUrl)
        {
           string email= User.FindFirst(ClaimTypes.Email)?.Value;

            if (ImageUrl == null || ImageUrl.Length == 0)
                return BadRequest("Image not uploaded.");

            var imgdata = ConvertImageToByteArray(ImageUrl);


            Post dbsaved = new Post
            {
                Email = email,
                Caption = ps.Caption,
                ImageUrl = imgdata,
                Tags = ps.Tags,
                Category = ps.Category
            };
            _dbcon.Posts.Add(dbsaved);
            _dbcon.SaveChanges();
            return Json("Successful");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }



    }


}
